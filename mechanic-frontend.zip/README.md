# Mechanic Booking System

A mobile-first booking form for a mechanic or roadside assistance service.

## Features

- Responsive design
- Select service type, time, GPS/manual location, and job description
- Confirmation message
- Future-ready for backend/API connection
